# A Simple Counter

A silly little application for learning Redux Toolkit during Steve's Advanced Redux course. Watch the full course at [Frontend Masters](https://frontendmasters.com/courses/advanced-redux/).

