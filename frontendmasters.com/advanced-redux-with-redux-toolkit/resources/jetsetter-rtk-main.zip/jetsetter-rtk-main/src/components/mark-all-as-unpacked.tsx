const MarkAllAsUnpacked = () => (
  <div className="mb-16">
    <button className="w-full">🏠 Mark All As Unpacked</button>
  </div>
);

export default MarkAllAsUnpacked;
