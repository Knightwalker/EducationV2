type Item = {
  id: string;
  name: string;
  packed: boolean;
};
