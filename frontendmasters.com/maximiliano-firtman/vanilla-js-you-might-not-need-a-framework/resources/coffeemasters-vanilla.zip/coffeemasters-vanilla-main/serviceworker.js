self.addEventListener("install", async event => {
   // TODO
});

self.addEventListener("fetch", async event => {
   // TODO
});