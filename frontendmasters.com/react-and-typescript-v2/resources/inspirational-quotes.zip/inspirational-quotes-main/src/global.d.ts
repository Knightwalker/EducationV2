type QuoteFilters = {
  content: string;
  source: string;
};
