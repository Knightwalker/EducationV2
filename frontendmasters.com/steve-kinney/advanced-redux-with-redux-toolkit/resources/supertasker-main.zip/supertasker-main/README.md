# Super Kanban

This is an example application for [Steve](https://twitter.com/stevekinney)'s Advanced Redux course. Watch the full course at [Frontend Masters](https://frontendmasters.com/courses/advanced-redux/).
