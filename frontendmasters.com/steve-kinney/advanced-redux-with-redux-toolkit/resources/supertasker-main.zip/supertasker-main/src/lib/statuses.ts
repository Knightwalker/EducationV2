export const statuses = [
  'Backburner',
  'Ready',
  'In Progress',
  'Verifying',
  'Waiting for Deployment',
  'Deployed',
] as const;
