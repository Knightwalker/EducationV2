# A Simple Counter

A silly little application for Steve's Redux Toolkit Course.
